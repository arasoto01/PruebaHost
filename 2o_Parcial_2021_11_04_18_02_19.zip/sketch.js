var LmfaoEImg;
var LmfaoESonido;

var CarlyEImg;
var CarlyESonido;

var BrunoEImg;
var BrunoESonido;

var KatyEImg;
var KatyESonido;

var TaylorEImg;
var TaylorESonido;


var Fondo 


var botonX = [];
var botonY = [];
var botonSz = [];


var botonStop = "apagado";


var totalBotones = 5;



function preload() {
  
  
Fondo = loadImage("Fondo.png");
  
  
LmfaoEImg = loadImage("LmfaoE.png");
LmfaoESonido = loadSound("LmfaoE.mp3");

CarlyEImg = loadImage("CarlyE.png");
CarlyESonido = loadSound("CarlyE.mp3");

BrunoEImg = loadImage("BrunoE.png");
BrunoESonido = loadSound("BrunoE.mp3");

KatyEImg = loadImage("KatyE.png");
KatyESonido = loadSound("KatyE.mp3");  
  
TaylorEImg = loadImage("TaylorE.png");
TaylorESonido = loadSound("TaylorE.mp3");
  
  
  
}



function setup() {
createCanvas(1200,600);

  
 for (var i = 0; i < totalBotones; i += 1) {
botonX = append(botonX, random(0, width));
botonY = append(botonY, random(0, height));
botonSz = append(botonSz, 50);
}
}



function draw() {
background(220);
  
  
imageMode(CORNER);
image(Fondo, 0, 0, width, height);
  

 for (var i = 0; i < totalBotones; i += 1) {
fill(186,139,139);
noStroke(0)
ellipse(botonX[i], botonY[i], botonSz[i], botonSz[i]);

   
   
fill(223,165,165);
noStroke(0)
ellipse(mouseX, mouseY, botonSz[i], botonSz[i])

   
 var distancia = dist(mouseX, mouseY, botonX[i], botonY[i]);
   
   

 if (distancia <= botonSz[i]) {
if (mouseIsPressed) {

  
  
//boton1
if (botonX[i] == botonX[0]) {
image(LmfaoEImg,400,200, width/3, height/3);

 if (LmfaoESonido.isPlaying()) {
} else {
LmfaoESonido.play();
}
}

  
   
//boton2
if (botonX[i] == botonX[1]) {
image(CarlyEImg,400,200, width/3, height/3);

 if (CarlyESonido.isPlaying()) {
} else {
CarlyESonido.play();
}
}
  

  
//boton3
if(botonX[i] == botonX[2]){
image(BrunoEImg,400,200, width/3, height/3);
  
 if(BrunoESonido.isPlaying()){
} else {
BrunoESonido.play();
}
}

  

//boton4
if(botonX[i] == botonX[3]){
image(KatyEImg,400,200, width/3, height/3);
  
 if(KatyESonido.isPlaying()){
} else {
KatyESonido.play();
}
} 
 
  
  
//boton5
if(botonX[i] == botonX[4]){
image(TaylorEImg,400,200,width/3, height/3);
  
  if(TaylorESonido.isPlaying()){
 } else {
TaylorESonido.play();
}
}
  
  
  
}
}
}
}



function keyTyped(){
  
if (key == "m") {
if (LmfaoESonido.isPlaying()) {
LmfaoESonido.stop();
} else {
}

    
if (CarlyESonido.isPlaying()) {
CarlyESonido.stop();
} else {
}  
  
  
if (BrunoESonido.isPlaying()) {
BrunoESonido.stop();
} else {
}
  

if (KatyESonido.isPlaying()) {
KatyESonido.stop();
} else {
}
  
  
if (TaylorESonido.isPlaying()) {
TaylorESonido.stop();
} else {
}
}
}